package com.example.madgroupproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class LocationScreen extends AppCompatActivity {

    Button btnTimetable = null;
    Button btnMain = null;
    Button btnTransport = null;
    Button addLocation = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_location_screen);

        btnTimetable = findViewById(R.id.btnTimetable);
        btnMain = findViewById(R.id.btnMain);
        btnTransport = findViewById(R.id.btnTransport);
        addLocation = findViewById(R.id.btnAddLocat);

        addLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View e) {
                startActivity(new Intent(LocationScreen.this, LocationPopup.class));
            }
        });

        btnTimetable.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View e) {
                Intent i = new Intent(LocationScreen.this, TimetableScreen.class);
                startActivity(i);
            }
        });

        btnMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View e) {
                Intent i = new Intent(LocationScreen.this, MainActivity.class);
                startActivity(i);
            }
        });

        btnTransport.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View e) {
                Intent i = new Intent(LocationScreen.this, TransportScreen.class);
                startActivity(i);
            }
        });
    }
}
