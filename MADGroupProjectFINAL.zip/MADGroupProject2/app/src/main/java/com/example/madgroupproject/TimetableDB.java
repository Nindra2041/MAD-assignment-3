package com.example.madgroupproject;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class TimetableDB extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "STUDENT_TIMETABLE";
    private static final String TABLE = "timetable";
    private static final String SUB = "Class";
    private static final String DAY = "Day";
    private static final String TIME = "StartTime";
    private static final String ETIME = "EndTime";
    private static final String ROOM = "Room";

    public TimetableDB(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_TIMETABLE = "CREATE TABLE /*IF NOT EXISTS*/ " + TABLE + "("
                + SUB + " TEXT," + DAY + " TEXT,"
                + TIME + " TEXT," + ETIME + " TEXT," + ROOM + " TEXT, PRIMARY KEY(" + SUB + ", " + TIME + "))";
        db.execSQL(CREATE_TIMETABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldV, int newV) {
        // Drop older table if existed
        db.execSQL("DROP TABLE IF EXISTS " + TABLE);
        // Create table again
        onCreate(db);
    }

    public void addClass(String stuClass, String day, String time, String eTime, String room) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(SUB, stuClass);
        values.put(DAY, day);
        values.put(TIME, time);
        values.put(ETIME, eTime);
        values.put(ROOM, room);

        db.insert(TABLE, null, values);
        db.close();
    }

    public List<String[]> getTimetable() {
        List<String[]> userTimetable = new ArrayList<>();

        String stmt = "SELECT * FROM " + TABLE;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(stmt, null);
        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                String[] classes = new String[5];
                classes[0] = cursor.getString(0);
                classes[1] = cursor.getString(1);
                classes[2] = cursor.getString(2);
                classes[3] = cursor.getString(3);
                classes[4] = cursor.getString(4);

                userTimetable.add(classes);

            } while (cursor.moveToNext());
        }
        cursor.close();

        return userTimetable;
    }

    public List<String> getUniDays() {
        List<String> uniDays = new ArrayList<>();

        String stmt = "SELECT day FROM " + TABLE;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(stmt, null);
        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                uniDays.add(cursor.getString(0));
            } while (cursor.moveToNext());
        }
        cursor.close();

        return uniDays;
    }

    public List<String[]> getUniTimes(String day) {
        List<String[]> uniTime = new ArrayList<>();

        String stmt = "SELECT startTime, endTIme FROM " + TABLE + " WHERE day = '" + day + "'";

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(stmt, null);
        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                String[] times = new String[2];

                times[0] = cursor.getString(0);
                times[1] = cursor.getString(1);

                uniTime.add(times);
            } while (cursor.moveToNext());
        }
        cursor.close();

        return uniTime;
    }

    public void deleteClass(String stuClass) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE, SUB + " = ?", new String[] {stuClass});
        db.close();
    }

    /*
        TODO (if time)
        update class
     */

}
