package com.example.madgroupproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

public class TransportScreen extends AppCompatActivity {

    Button btnTimetable = null;
    Button btnLocations = null;
    Button btnMain = null;
    Spinner unis = null;
    public static LatLngFinder uni;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_transport_screen);

        btnTimetable = findViewById(R.id.btnTimetable);
        btnLocations = findViewById(R.id.btnLocation);
        btnMain = findViewById(R.id.btnMain);
        unis = findViewById(R.id.unis);

        String[] daysSpinner = new String[] {"Latrobe Uni Sydney"};

        ArrayAdapter<String> adapt = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, daysSpinner);

        unis.setAdapter(adapt);

        uni = new LatLngFinder(unis.getSelectedItem().toString());

        unis.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                uni = new LatLngFinder(unis.getSelectedItem().toString());
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        btnTimetable.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View e) {
                Intent i = new Intent(TransportScreen.this, TimetableScreen.class);
                startActivity(i);
            }
        });

        btnLocations.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View e) {
                Intent i = new Intent(TransportScreen.this, LocationScreen.class);
                startActivity(i);
            }
        });

        btnMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View e) {
                Intent i = new Intent(TransportScreen.this, MainActivity.class);
                startActivity(i);
            }
        });
    }
}
