package com.example.madgroupproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.provider.AlarmClock;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    TextView txtTime;
    Button btnSetAlarm = null;
    Button btnTimetable = null;
    Button btnLocations = null;
    Button btnTransport = null;
    TimetableDB db = new TimetableDB(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtTime = findViewById(R.id.txtTimeEnd);
        btnTimetable = findViewById(R.id.btnTimetable);
        btnLocations = findViewById(R.id.btnLocation);
        btnTransport = findViewById(R.id.btnTransport);

        String alarmStr = null;

        //get distance from uni and calculate the time from that
        SimpleDateFormat dateFormat = new SimpleDateFormat("h:mm a");
        String currTime = dateFormat.format(new Date());

        Calendar calendar = Calendar.getInstance();
        int day = calendar.get(Calendar.DAY_OF_WEEK);

        List<String> daysAtUni = db.getUniDays();
        List<String[]> uniTimes = null;

        for(String uniDays : daysAtUni) {
            if(day == Calendar.MONDAY && uniDays.equals("Mon")) {
                alarmStr = "Tuesday ";
                uniTimes = db.getUniTimes("Mon");
                break;
            } else if(day == Calendar.TUESDAY && uniDays.equals("Tue")) {
                alarmStr = "Wednesday ";
                uniTimes = db.getUniTimes("Tue");
                break;
            } else if(day == Calendar.WEDNESDAY && uniDays.equals("Wed")) {
                alarmStr = "Thursday ";
                uniTimes = db.getUniTimes("Wed");
                break;
            } else if(day == Calendar.THURSDAY && uniDays.equals("Thu")) {
                alarmStr = "Friday ";
                uniTimes = db.getUniTimes("Thu");
                break;
            } else if(day == Calendar.FRIDAY && uniDays.equals("Fri")) {
                alarmStr = "Monday ";
                uniTimes = db.getUniTimes("Mon");
                break;
            } else if(day == Calendar.SATURDAY && uniDays.equals("Sat")) {
                alarmStr = "Monday ";
                uniTimes = db.getUniTimes("Mon");
                break;
            } else if(day == Calendar.SUNDAY && uniDays.equals("Sun")) {
                alarmStr = "Monday ";
                uniTimes = db.getUniTimes("Mon");
                break;
            }
        }

        txtTime.setText(alarmStr + "\nYou have classes at these times: \n");

        if(uniTimes != null) {
            for (String[] times : uniTimes) {
                txtTime.append("Start: " + times[0]);
                txtTime.append(", End: " + times[1] + "\n");
            }
        } else {
            txtTime.setText("You have no classes on " + alarmStr + ".\nYou don't need to set an alarm");
        }

        btnTimetable.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View e) {
                Intent i = new Intent(MainActivity.this, TimetableScreen.class);
                startActivity(i);
            }
        });

        btnLocations.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View e) {
                Intent i = new Intent(MainActivity.this, LocationScreen.class);
                startActivity(i);
            }
        });

        btnTransport.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View e) {
                Intent i = new Intent(MainActivity.this, TransportScreen.class);
                startActivity(i);
            }
        });
    }

    //https://developer.android.com/guide/components/intents-common#java
    //<action android:name="android.intent.action.SET_ALARM" />
    public void createAlarm(String message, int hour, int minutes) {
        Intent intent = new Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_MESSAGE, message).putExtra(AlarmClock.EXTRA_HOUR, hour).putExtra(AlarmClock.EXTRA_MINUTES, minutes);
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        }
    }

}
