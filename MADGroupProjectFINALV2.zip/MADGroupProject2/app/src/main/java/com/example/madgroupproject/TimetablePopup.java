package com.example.madgroupproject;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

public class TimetablePopup extends Activity {

    TextView txtClass = null;
    Spinner days = null;
    TextView txtTime = null;
    TextView txtTimeEnd = null;
    TextView txtRoom = null;
    Button btnSave = null;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_timetable_popup);

        final TimetableDB db = new TimetableDB(this);

        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);

        int width = dm.widthPixels;
        int height = dm.heightPixels;

        //getWindow().setLayout((int)(width * 0.8), (int)(height*0.6));

        txtClass = findViewById(R.id.txtClass);
        days = findViewById(R.id.days);
        txtTime = findViewById(R.id.txtTime);
        txtTimeEnd = findViewById(R.id.txtTimeEnd);
        txtRoom = findViewById(R.id.txtRoom);
        btnSave = findViewById(R.id.btnSave);
        btnSave.setEnabled(false);

        String[] daysSpinner = new String[] {"Select Day", "Mon", "Tue", "Wed", "Thu", "Fri"};

        ArrayAdapter<String> adapt = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, daysSpinner);

        days.setAdapter(adapt);

        txtClass.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                if(txtClass.getText().toString().isEmpty() || days.getSelectedItem().toString().equals("Select Day") || txtTime.getText().toString().isEmpty() || txtTimeEnd.getText().toString().isEmpty() || txtRoom.getText().toString().isEmpty()) {
                    btnSave.setEnabled(false);
                } else {
                    btnSave.setEnabled(true);
                }
            }
        });

        days.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                if(txtClass.getText().toString().isEmpty() || days.getSelectedItem().toString().equals("Select Day") || txtTime.getText().toString().isEmpty() || txtTimeEnd.getText().toString().isEmpty() || txtRoom.getText().toString().isEmpty()) {
                    btnSave.setEnabled(false);
                } else {
                    btnSave.setEnabled(true);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        txtTime.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                if(txtClass.getText().toString().isEmpty() || days.getSelectedItem().toString().equals("Select Day") || txtTime.getText().toString().isEmpty() || txtTimeEnd.getText().toString().isEmpty() || txtRoom.getText().toString().isEmpty()) {
                    btnSave.setEnabled(false);
                } else {
                    btnSave.setEnabled(true);
                }
            }
        });

        txtTimeEnd.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                if(txtClass.getText().toString().isEmpty() || days.getSelectedItem().toString().equals("Select Day") || txtTime.getText().toString().isEmpty() || txtTimeEnd.getText().toString().isEmpty() || txtRoom.getText().toString().isEmpty()) {
                    btnSave.setEnabled(false);
                } else {
                    btnSave.setEnabled(true);
                }
            }
        });

        txtRoom.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                if(txtClass.getText().toString().isEmpty() || days.getSelectedItem().toString().equals("Select Day") || txtTime.getText().toString().isEmpty() || txtTimeEnd.getText().toString().isEmpty() || txtRoom.getText().toString().isEmpty()) {
                    btnSave.setEnabled(false);
                } else {
                    btnSave.setEnabled(true);
                }
            }
        });

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View e) {
                db.addClass(txtClass.getText().toString(), days.getSelectedItem().toString(), txtTime.getText().toString(), txtTimeEnd.getText().toString(), txtRoom.getText().toString());
                Intent i = new Intent(TimetablePopup.this, TimetableScreen.class);
                startActivity(i);
            }
        });

    }

}
