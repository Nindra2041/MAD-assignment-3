package com.example.madgroupproject;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.OnLifecycleEvent;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import java.util.List;

public class TimetableScreen extends AppCompatActivity {

    Button btnMain = null;
    Button btnLocations = null;
    Button btnTransport = null;
    Button btnAddClass = null;
    Button btnDel = null;
    TableLayout tbl = null;
    TableRow tr = null;
    TextView txtClass = null;
    TextView txtDay = null;
    TextView txtStart = null;
    TextView txtEnd = null;
    TextView txtRoom = null;
    TimetableDB db = new TimetableDB(this);

    private static String[][] timetables = new String[4][4];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_timetable_screen);

        btnMain = findViewById(R.id.btnMain);
        btnLocations = findViewById(R.id.btnLocation);
        btnTransport = findViewById(R.id.btnTransport);
        btnAddClass = findViewById(R.id.btnAddClass);
        tbl = findViewById(R.id.tbl);
        tr = findViewById(R.id.tr);
        txtClass = findViewById(R.id.txtClass);
        txtDay = findViewById(R.id.txtDay);
        txtStart = findViewById(R.id.txtStart);
        txtEnd = findViewById(R.id.txtEnd);
        txtRoom = findViewById(R.id.txtRoom);
        btnDel = findViewById(R.id.btnRemove);

        btnAddClass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View e) {
                Intent i = new Intent(TimetableScreen.this, TimetablePopup.class);
                startActivity(i);
            }
        });

        btnDel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                db.deleteTimetable();
                Intent i = new Intent(TimetableScreen.this, TimetableScreen.class);
                startActivity(i);
                overridePendingTransition(0, 0);
            }
        });

        btnMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View e) {
                Intent i = new Intent(TimetableScreen.this, MainActivity.class);
                startActivity(i);
            }
        });

        btnLocations.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View e) {
                Intent i = new Intent(TimetableScreen.this, LocationScreen.class);
                startActivity(i);
            }
        });

        btnTransport.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View e) {
                Intent i = new Intent(TimetableScreen.this, TransportScreen.class);
                startActivity(i);
            }
        });
    }

    protected void onResume() {
        super.onResume();
        setTimetable();
    }

    public void setTimetable() {
        List<String[]> timetable = db.getTimetable();
        /*
            TODO (IF TIME)
            Delete timetable
         */

        if (timetable.size() > 0) {
            String[] t = timetable.get(0);
            txtClass.setText(t[0]);
            txtDay.setText(t[1]);
            txtStart.setText(t[2]);
            txtEnd.setText(t[3]);
            txtRoom.setText(t[4]);

            for (String[] disp : timetable.subList(1, timetable.size())) {
                TableRow tr1 = new TableRow(this);
                tr1.setLayoutParams(tr.getLayoutParams());

                TextView tvClass = new TextView(this);
                tvClass.setLayoutParams(txtClass.getLayoutParams());
                tvClass.setGravity(Gravity.CENTER);

                TextView tvDay = new TextView(this);
                tvDay.setLayoutParams(txtDay.getLayoutParams());
                tvDay.setGravity(Gravity.CENTER);

                TextView tvStart = new TextView(this);
                tvStart.setLayoutParams(txtStart.getLayoutParams());
                tvStart.setGravity(Gravity.CENTER);

                TextView tvEnd = new TextView(this);
                tvEnd.setLayoutParams(txtEnd.getLayoutParams());
                tvEnd.setGravity(Gravity.CENTER);

                TextView tvRoom = new TextView(this);
                tvRoom.setLayoutParams(txtRoom.getLayoutParams());
                tvRoom.setGravity(Gravity.CENTER);

                tvClass.setText(disp[0]);
                tvDay.setText(disp[1]);
                tvStart.setText(disp[2]);
                tvEnd.setText(disp[3]);
                tvRoom.setText(disp[4]);

                tbl.addView(tr1);

                tr1.addView(tvClass);
                tr1.addView(tvDay);
                tr1.addView(tvStart);
                tr1.addView(tvEnd);
                tr1.addView(tvRoom);
            }
        }
    }

    protected void onDestroy() {
        super.onDestroy();
        db.close();
    }
}
