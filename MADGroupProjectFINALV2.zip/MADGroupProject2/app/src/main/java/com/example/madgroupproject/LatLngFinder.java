package com.example.madgroupproject;

import com.google.android.gms.maps.model.LatLng;

public class LatLngFinder {

    private LatLng loc;
    LatLngFinder(String uni) {
        if(uni.equals("Latrobe Uni Sydney")) {
            this.loc = new LatLng(-33.875710, 151.209200);
        }
    }

    public LatLng getLatLng() {
        return this.loc;
    }
}
